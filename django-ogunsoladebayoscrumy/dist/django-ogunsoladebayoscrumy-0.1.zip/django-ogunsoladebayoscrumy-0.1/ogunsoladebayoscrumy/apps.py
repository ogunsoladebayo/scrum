from django.apps import AppConfig


class OgunsoladebayoscrumyConfig(AppConfig):
    name = 'ogunsoladebayoscrumy'
